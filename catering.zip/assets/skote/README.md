# Skote #

Skote Theme by Themesbrand.

### Getting Started ###

The steps to compile and get started with development are covered in detail in documentation mentioned above, but the summary is:

- yarn install
- gulp

### Support ###

Themesbrand is happy to provide support for issues. Shoot us an email at support@themesbrand.com and we'll get you squared away.