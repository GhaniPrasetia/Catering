<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-10-29 11:04:53 --> Config Class Initialized
INFO - 2022-10-29 11:04:53 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:04:53 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:04:53 --> Utf8 Class Initialized
INFO - 2022-10-29 11:04:53 --> URI Class Initialized
DEBUG - 2022-10-29 11:04:53 --> No URI present. Default controller set.
INFO - 2022-10-29 11:04:53 --> Router Class Initialized
INFO - 2022-10-29 11:04:53 --> Output Class Initialized
INFO - 2022-10-29 11:04:53 --> Security Class Initialized
DEBUG - 2022-10-29 11:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:04:53 --> Input Class Initialized
INFO - 2022-10-29 11:04:53 --> Language Class Initialized
INFO - 2022-10-29 11:04:53 --> Loader Class Initialized
INFO - 2022-10-29 11:04:53 --> Helper loaded: url_helper
INFO - 2022-10-29 11:04:53 --> Helper loaded: file_helper
INFO - 2022-10-29 11:04:53 --> Helper loaded: session_helper
INFO - 2022-10-29 11:04:53 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:04:53 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:04:53 --> Database Driver Class Initialized
INFO - 2022-10-29 11:04:53 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:04:53 --> Controller Class Initialized
INFO - 2022-10-29 11:04:53 --> File loaded: /var/www/app/omahan/application/views/login/index.php
INFO - 2022-10-29 11:04:53 --> Final output sent to browser
DEBUG - 2022-10-29 11:04:53 --> Total execution time: 0.2439
INFO - 2022-10-29 11:04:55 --> Config Class Initialized
INFO - 2022-10-29 11:04:55 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:04:55 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:04:55 --> Utf8 Class Initialized
INFO - 2022-10-29 11:04:55 --> URI Class Initialized
INFO - 2022-10-29 11:04:55 --> Router Class Initialized
INFO - 2022-10-29 11:04:55 --> Output Class Initialized
INFO - 2022-10-29 11:04:55 --> Security Class Initialized
DEBUG - 2022-10-29 11:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:04:55 --> Input Class Initialized
INFO - 2022-10-29 11:04:55 --> Language Class Initialized
INFO - 2022-10-29 11:04:55 --> Loader Class Initialized
INFO - 2022-10-29 11:04:55 --> Helper loaded: url_helper
INFO - 2022-10-29 11:04:55 --> Helper loaded: file_helper
INFO - 2022-10-29 11:04:55 --> Helper loaded: session_helper
INFO - 2022-10-29 11:04:55 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:04:55 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:04:55 --> Database Driver Class Initialized
INFO - 2022-10-29 11:04:55 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:04:55 --> Controller Class Initialized
INFO - 2022-10-29 11:05:00 --> Config Class Initialized
INFO - 2022-10-29 11:05:00 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:00 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:00 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:00 --> URI Class Initialized
INFO - 2022-10-29 11:05:00 --> Router Class Initialized
INFO - 2022-10-29 11:05:00 --> Output Class Initialized
INFO - 2022-10-29 11:05:00 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:00 --> Input Class Initialized
INFO - 2022-10-29 11:05:00 --> Language Class Initialized
INFO - 2022-10-29 11:05:00 --> Loader Class Initialized
INFO - 2022-10-29 11:05:00 --> Helper loaded: url_helper
INFO - 2022-10-29 11:05:00 --> Helper loaded: file_helper
INFO - 2022-10-29 11:05:00 --> Helper loaded: session_helper
INFO - 2022-10-29 11:05:00 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:05:00 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:05:00 --> Database Driver Class Initialized
INFO - 2022-10-29 11:05:00 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:05:00 --> Controller Class Initialized
INFO - 2022-10-29 11:05:06 --> Config Class Initialized
INFO - 2022-10-29 11:05:06 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:06 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:06 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:06 --> URI Class Initialized
INFO - 2022-10-29 11:05:06 --> Router Class Initialized
INFO - 2022-10-29 11:05:06 --> Output Class Initialized
INFO - 2022-10-29 11:05:06 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:06 --> Input Class Initialized
INFO - 2022-10-29 11:05:06 --> Language Class Initialized
INFO - 2022-10-29 11:05:06 --> Loader Class Initialized
INFO - 2022-10-29 11:05:06 --> Helper loaded: url_helper
INFO - 2022-10-29 11:05:06 --> Helper loaded: file_helper
INFO - 2022-10-29 11:05:06 --> Helper loaded: session_helper
INFO - 2022-10-29 11:05:06 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:05:06 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:05:06 --> Database Driver Class Initialized
INFO - 2022-10-29 11:05:06 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:05:06 --> Controller Class Initialized
INFO - 2022-10-29 11:05:07 --> Config Class Initialized
INFO - 2022-10-29 11:05:07 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:07 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:07 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:07 --> URI Class Initialized
INFO - 2022-10-29 11:05:07 --> Router Class Initialized
INFO - 2022-10-29 11:05:07 --> Output Class Initialized
INFO - 2022-10-29 11:05:07 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:07 --> Input Class Initialized
INFO - 2022-10-29 11:05:07 --> Language Class Initialized
INFO - 2022-10-29 11:05:07 --> Loader Class Initialized
INFO - 2022-10-29 11:05:07 --> Helper loaded: url_helper
INFO - 2022-10-29 11:05:07 --> Helper loaded: file_helper
INFO - 2022-10-29 11:05:07 --> Helper loaded: session_helper
INFO - 2022-10-29 11:05:07 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:05:07 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:05:07 --> Database Driver Class Initialized
INFO - 2022-10-29 11:05:07 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:05:07 --> Controller Class Initialized
INFO - 2022-10-29 11:05:07 --> File loaded: /var/www/app/omahan/application/views/super_admin/dashboard/index.php
INFO - 2022-10-29 11:05:07 --> File loaded: /var/www/app/omahan/application/views/super_admin/dashboard/index_js.php
INFO - 2022-10-29 11:05:07 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 11:05:07 --> Final output sent to browser
DEBUG - 2022-10-29 11:05:07 --> Total execution time: 0.1745
INFO - 2022-10-29 11:05:07 --> Config Class Initialized
INFO - 2022-10-29 11:05:07 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:07 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:07 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:07 --> URI Class Initialized
INFO - 2022-10-29 11:05:07 --> Router Class Initialized
INFO - 2022-10-29 11:05:07 --> Output Class Initialized
INFO - 2022-10-29 11:05:07 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:07 --> Input Class Initialized
INFO - 2022-10-29 11:05:07 --> Language Class Initialized
ERROR - 2022-10-29 11:05:07 --> 404 Page Not Found: Uploads/users
INFO - 2022-10-29 11:05:12 --> Config Class Initialized
INFO - 2022-10-29 11:05:12 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:12 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:12 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:12 --> URI Class Initialized
INFO - 2022-10-29 11:05:12 --> Router Class Initialized
INFO - 2022-10-29 11:05:12 --> Output Class Initialized
INFO - 2022-10-29 11:05:12 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:12 --> Input Class Initialized
INFO - 2022-10-29 11:05:12 --> Language Class Initialized
INFO - 2022-10-29 11:05:12 --> Loader Class Initialized
INFO - 2022-10-29 11:05:12 --> Helper loaded: url_helper
INFO - 2022-10-29 11:05:12 --> Helper loaded: file_helper
INFO - 2022-10-29 11:05:12 --> Helper loaded: session_helper
INFO - 2022-10-29 11:05:12 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:05:12 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:05:12 --> Database Driver Class Initialized
INFO - 2022-10-29 11:05:12 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:05:12 --> Controller Class Initialized
INFO - 2022-10-29 11:05:12 --> File loaded: /var/www/app/omahan/application/views/super_admin/dashboard/index.php
INFO - 2022-10-29 11:05:12 --> File loaded: /var/www/app/omahan/application/views/super_admin/dashboard/index_js.php
INFO - 2022-10-29 11:05:12 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 11:05:12 --> Final output sent to browser
DEBUG - 2022-10-29 11:05:12 --> Total execution time: 0.1698
INFO - 2022-10-29 11:05:13 --> Config Class Initialized
INFO - 2022-10-29 11:05:13 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:13 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:13 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:13 --> URI Class Initialized
INFO - 2022-10-29 11:05:13 --> Router Class Initialized
INFO - 2022-10-29 11:05:13 --> Output Class Initialized
INFO - 2022-10-29 11:05:13 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:13 --> Input Class Initialized
INFO - 2022-10-29 11:05:13 --> Language Class Initialized
ERROR - 2022-10-29 11:05:13 --> 404 Page Not Found: Uploads/users
INFO - 2022-10-29 11:05:18 --> Config Class Initialized
INFO - 2022-10-29 11:05:18 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:18 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:18 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:18 --> URI Class Initialized
INFO - 2022-10-29 11:05:18 --> Router Class Initialized
INFO - 2022-10-29 11:05:18 --> Output Class Initialized
INFO - 2022-10-29 11:05:18 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:18 --> Input Class Initialized
INFO - 2022-10-29 11:05:18 --> Language Class Initialized
INFO - 2022-10-29 11:05:18 --> Loader Class Initialized
INFO - 2022-10-29 11:05:18 --> Helper loaded: url_helper
INFO - 2022-10-29 11:05:18 --> Helper loaded: file_helper
INFO - 2022-10-29 11:05:18 --> Helper loaded: session_helper
INFO - 2022-10-29 11:05:18 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:05:18 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:05:18 --> Database Driver Class Initialized
INFO - 2022-10-29 11:05:18 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:05:18 --> Controller Class Initialized
INFO - 2022-10-29 11:05:18 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_super_admin.php
INFO - 2022-10-29 11:05:18 --> File loaded: /var/www/app/omahan/application/views/profil/index.php
INFO - 2022-10-29 11:05:18 --> File loaded: /var/www/app/omahan/application/views/profil/index_js.php
INFO - 2022-10-29 11:05:18 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 11:05:18 --> Final output sent to browser
DEBUG - 2022-10-29 11:05:18 --> Total execution time: 0.1744
INFO - 2022-10-29 11:05:18 --> Config Class Initialized
INFO - 2022-10-29 11:05:18 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:18 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:18 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:18 --> URI Class Initialized
INFO - 2022-10-29 11:05:18 --> Router Class Initialized
INFO - 2022-10-29 11:05:18 --> Output Class Initialized
INFO - 2022-10-29 11:05:18 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:18 --> Input Class Initialized
INFO - 2022-10-29 11:05:18 --> Language Class Initialized
ERROR - 2022-10-29 11:05:18 --> 404 Page Not Found: Uploads/users
INFO - 2022-10-29 11:05:20 --> Config Class Initialized
INFO - 2022-10-29 11:05:20 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:20 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:20 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:20 --> URI Class Initialized
INFO - 2022-10-29 11:05:20 --> Router Class Initialized
INFO - 2022-10-29 11:05:20 --> Output Class Initialized
INFO - 2022-10-29 11:05:20 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:20 --> Input Class Initialized
INFO - 2022-10-29 11:05:20 --> Language Class Initialized
INFO - 2022-10-29 11:05:20 --> Loader Class Initialized
INFO - 2022-10-29 11:05:20 --> Helper loaded: url_helper
INFO - 2022-10-29 11:05:20 --> Helper loaded: file_helper
INFO - 2022-10-29 11:05:20 --> Helper loaded: session_helper
INFO - 2022-10-29 11:05:20 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:05:20 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:05:20 --> Database Driver Class Initialized
INFO - 2022-10-29 11:05:20 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:05:20 --> Controller Class Initialized
INFO - 2022-10-29 11:05:20 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_super_admin.php
INFO - 2022-10-29 11:05:20 --> File loaded: /var/www/app/omahan/application/views/profil/edit.php
INFO - 2022-10-29 11:05:20 --> File loaded: /var/www/app/omahan/application/views/profil/edit_js.php
INFO - 2022-10-29 11:05:20 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 11:05:20 --> Final output sent to browser
DEBUG - 2022-10-29 11:05:20 --> Total execution time: 0.4626
INFO - 2022-10-29 11:05:20 --> Config Class Initialized
INFO - 2022-10-29 11:05:20 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:20 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:20 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:20 --> URI Class Initialized
INFO - 2022-10-29 11:05:20 --> Router Class Initialized
INFO - 2022-10-29 11:05:20 --> Output Class Initialized
INFO - 2022-10-29 11:05:20 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:20 --> Input Class Initialized
INFO - 2022-10-29 11:05:20 --> Language Class Initialized
ERROR - 2022-10-29 11:05:20 --> 404 Page Not Found: Uploads/users
INFO - 2022-10-29 11:05:50 --> Config Class Initialized
INFO - 2022-10-29 11:05:50 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:50 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:50 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:50 --> URI Class Initialized
INFO - 2022-10-29 11:05:50 --> Router Class Initialized
INFO - 2022-10-29 11:05:50 --> Output Class Initialized
INFO - 2022-10-29 11:05:50 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:50 --> Input Class Initialized
INFO - 2022-10-29 11:05:50 --> Language Class Initialized
INFO - 2022-10-29 11:05:50 --> Loader Class Initialized
INFO - 2022-10-29 11:05:50 --> Helper loaded: url_helper
INFO - 2022-10-29 11:05:50 --> Helper loaded: file_helper
INFO - 2022-10-29 11:05:50 --> Helper loaded: session_helper
INFO - 2022-10-29 11:05:50 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:05:50 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:05:50 --> Database Driver Class Initialized
INFO - 2022-10-29 11:05:50 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:05:50 --> Controller Class Initialized
INFO - 2022-10-29 11:05:50 --> Final output sent to browser
DEBUG - 2022-10-29 11:05:50 --> Total execution time: 0.1715
INFO - 2022-10-29 11:05:52 --> Config Class Initialized
INFO - 2022-10-29 11:05:52 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:52 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:52 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:52 --> URI Class Initialized
INFO - 2022-10-29 11:05:52 --> Router Class Initialized
INFO - 2022-10-29 11:05:52 --> Output Class Initialized
INFO - 2022-10-29 11:05:52 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:52 --> Input Class Initialized
INFO - 2022-10-29 11:05:52 --> Language Class Initialized
INFO - 2022-10-29 11:05:52 --> Loader Class Initialized
INFO - 2022-10-29 11:05:52 --> Helper loaded: url_helper
INFO - 2022-10-29 11:05:52 --> Helper loaded: file_helper
INFO - 2022-10-29 11:05:52 --> Helper loaded: session_helper
INFO - 2022-10-29 11:05:52 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:05:52 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:05:52 --> Database Driver Class Initialized
INFO - 2022-10-29 11:05:52 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:05:52 --> Controller Class Initialized
INFO - 2022-10-29 11:05:52 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_super_admin.php
INFO - 2022-10-29 11:05:52 --> File loaded: /var/www/app/omahan/application/views/profil/index.php
INFO - 2022-10-29 11:05:52 --> File loaded: /var/www/app/omahan/application/views/profil/index_js.php
INFO - 2022-10-29 11:05:52 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 11:05:52 --> Final output sent to browser
DEBUG - 2022-10-29 11:05:52 --> Total execution time: 0.1744
INFO - 2022-10-29 11:05:56 --> Config Class Initialized
INFO - 2022-10-29 11:05:56 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:56 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:56 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:56 --> URI Class Initialized
INFO - 2022-10-29 11:05:56 --> Router Class Initialized
INFO - 2022-10-29 11:05:56 --> Output Class Initialized
INFO - 2022-10-29 11:05:56 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:56 --> Input Class Initialized
INFO - 2022-10-29 11:05:56 --> Language Class Initialized
INFO - 2022-10-29 11:05:56 --> Loader Class Initialized
INFO - 2022-10-29 11:05:56 --> Helper loaded: url_helper
INFO - 2022-10-29 11:05:56 --> Helper loaded: file_helper
INFO - 2022-10-29 11:05:56 --> Helper loaded: session_helper
INFO - 2022-10-29 11:05:56 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:05:56 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:05:56 --> Database Driver Class Initialized
INFO - 2022-10-29 11:05:56 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:05:56 --> Controller Class Initialized
INFO - 2022-10-29 11:05:56 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_super_admin.php
INFO - 2022-10-29 11:05:56 --> File loaded: /var/www/app/omahan/application/views/profil/index.php
INFO - 2022-10-29 11:05:56 --> File loaded: /var/www/app/omahan/application/views/profil/index_js.php
INFO - 2022-10-29 11:05:56 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 11:05:56 --> Final output sent to browser
DEBUG - 2022-10-29 11:05:56 --> Total execution time: 0.1473
INFO - 2022-10-29 11:05:58 --> Config Class Initialized
INFO - 2022-10-29 11:05:58 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:05:58 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:05:58 --> Utf8 Class Initialized
INFO - 2022-10-29 11:05:58 --> URI Class Initialized
INFO - 2022-10-29 11:05:58 --> Router Class Initialized
INFO - 2022-10-29 11:05:58 --> Output Class Initialized
INFO - 2022-10-29 11:05:58 --> Security Class Initialized
DEBUG - 2022-10-29 11:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:05:58 --> Input Class Initialized
INFO - 2022-10-29 11:05:58 --> Language Class Initialized
INFO - 2022-10-29 11:05:58 --> Loader Class Initialized
INFO - 2022-10-29 11:05:58 --> Helper loaded: url_helper
INFO - 2022-10-29 11:05:58 --> Helper loaded: file_helper
INFO - 2022-10-29 11:05:58 --> Helper loaded: session_helper
INFO - 2022-10-29 11:05:58 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:05:58 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:05:58 --> Database Driver Class Initialized
INFO - 2022-10-29 11:05:58 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:05:58 --> Controller Class Initialized
INFO - 2022-10-29 11:05:58 --> File loaded: /var/www/app/omahan/application/views/super_admin/dashboard/index.php
INFO - 2022-10-29 11:05:58 --> File loaded: /var/www/app/omahan/application/views/super_admin/dashboard/index_js.php
INFO - 2022-10-29 11:05:58 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 11:05:58 --> Final output sent to browser
DEBUG - 2022-10-29 11:05:58 --> Total execution time: 0.1473
INFO - 2022-10-29 11:06:00 --> Config Class Initialized
INFO - 2022-10-29 11:06:00 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:06:00 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:06:00 --> Utf8 Class Initialized
INFO - 2022-10-29 11:06:00 --> URI Class Initialized
INFO - 2022-10-29 11:06:00 --> Router Class Initialized
INFO - 2022-10-29 11:06:00 --> Output Class Initialized
INFO - 2022-10-29 11:06:00 --> Security Class Initialized
DEBUG - 2022-10-29 11:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:06:00 --> Input Class Initialized
INFO - 2022-10-29 11:06:00 --> Language Class Initialized
INFO - 2022-10-29 11:06:00 --> Loader Class Initialized
INFO - 2022-10-29 11:06:00 --> Helper loaded: url_helper
INFO - 2022-10-29 11:06:00 --> Helper loaded: file_helper
INFO - 2022-10-29 11:06:00 --> Helper loaded: session_helper
INFO - 2022-10-29 11:06:00 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:06:00 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:06:00 --> Database Driver Class Initialized
INFO - 2022-10-29 11:06:00 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:06:00 --> Controller Class Initialized
INFO - 2022-10-29 11:06:00 --> File loaded: /var/www/app/omahan/application/views/super_admin/dashboard/modal_show_data.php
INFO - 2022-10-29 11:06:00 --> Final output sent to browser
DEBUG - 2022-10-29 11:06:00 --> Total execution time: 0.1357
INFO - 2022-10-29 11:06:10 --> Config Class Initialized
INFO - 2022-10-29 11:06:10 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:06:10 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:06:10 --> Utf8 Class Initialized
INFO - 2022-10-29 11:06:10 --> URI Class Initialized
INFO - 2022-10-29 11:06:10 --> Router Class Initialized
INFO - 2022-10-29 11:06:10 --> Output Class Initialized
INFO - 2022-10-29 11:06:10 --> Security Class Initialized
DEBUG - 2022-10-29 11:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:06:10 --> Input Class Initialized
INFO - 2022-10-29 11:06:10 --> Language Class Initialized
INFO - 2022-10-29 11:06:10 --> Loader Class Initialized
INFO - 2022-10-29 11:06:10 --> Helper loaded: url_helper
INFO - 2022-10-29 11:06:10 --> Helper loaded: file_helper
INFO - 2022-10-29 11:06:10 --> Helper loaded: session_helper
INFO - 2022-10-29 11:06:10 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:06:10 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:06:10 --> Database Driver Class Initialized
INFO - 2022-10-29 11:06:10 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:06:10 --> Controller Class Initialized
INFO - 2022-10-29 11:06:10 --> File loaded: /var/www/app/omahan/application/views/super_admin/dashboard/modal_show_data.php
INFO - 2022-10-29 11:06:10 --> Final output sent to browser
DEBUG - 2022-10-29 11:06:10 --> Total execution time: 0.1342
INFO - 2022-10-29 11:06:12 --> Config Class Initialized
INFO - 2022-10-29 11:06:12 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:06:12 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:06:12 --> Utf8 Class Initialized
INFO - 2022-10-29 11:06:12 --> URI Class Initialized
INFO - 2022-10-29 11:06:12 --> Router Class Initialized
INFO - 2022-10-29 11:06:12 --> Output Class Initialized
INFO - 2022-10-29 11:06:12 --> Security Class Initialized
DEBUG - 2022-10-29 11:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:06:12 --> Input Class Initialized
INFO - 2022-10-29 11:06:12 --> Language Class Initialized
INFO - 2022-10-29 11:06:12 --> Loader Class Initialized
INFO - 2022-10-29 11:06:12 --> Helper loaded: url_helper
INFO - 2022-10-29 11:06:12 --> Helper loaded: file_helper
INFO - 2022-10-29 11:06:12 --> Helper loaded: session_helper
INFO - 2022-10-29 11:06:12 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:06:12 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:06:12 --> Database Driver Class Initialized
INFO - 2022-10-29 11:06:12 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:06:12 --> Controller Class Initialized
INFO - 2022-10-29 11:06:12 --> Config Class Initialized
INFO - 2022-10-29 11:06:12 --> Hooks Class Initialized
DEBUG - 2022-10-29 11:06:12 --> UTF-8 Support Enabled
INFO - 2022-10-29 11:06:12 --> Utf8 Class Initialized
INFO - 2022-10-29 11:06:12 --> URI Class Initialized
INFO - 2022-10-29 11:06:12 --> Router Class Initialized
INFO - 2022-10-29 11:06:12 --> Output Class Initialized
INFO - 2022-10-29 11:06:12 --> Security Class Initialized
DEBUG - 2022-10-29 11:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 11:06:12 --> Input Class Initialized
INFO - 2022-10-29 11:06:12 --> Language Class Initialized
INFO - 2022-10-29 11:06:12 --> Loader Class Initialized
INFO - 2022-10-29 11:06:12 --> Helper loaded: url_helper
INFO - 2022-10-29 11:06:12 --> Helper loaded: file_helper
INFO - 2022-10-29 11:06:12 --> Helper loaded: session_helper
INFO - 2022-10-29 11:06:12 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 11:06:12 --> Helper loaded: referensi_helper
INFO - 2022-10-29 11:06:12 --> Database Driver Class Initialized
INFO - 2022-10-29 11:06:12 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 11:06:12 --> Controller Class Initialized
INFO - 2022-10-29 11:06:12 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_admin.php
INFO - 2022-10-29 11:06:12 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index.php
INFO - 2022-10-29 11:06:12 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index_js.php
INFO - 2022-10-29 11:06:12 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 11:06:12 --> Final output sent to browser
DEBUG - 2022-10-29 11:06:12 --> Total execution time: 0.1473
INFO - 2022-10-29 15:12:37 --> Config Class Initialized
INFO - 2022-10-29 15:12:37 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:12:37 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:12:37 --> Utf8 Class Initialized
INFO - 2022-10-29 15:12:37 --> URI Class Initialized
DEBUG - 2022-10-29 15:12:37 --> No URI present. Default controller set.
INFO - 2022-10-29 15:12:37 --> Router Class Initialized
INFO - 2022-10-29 15:12:37 --> Output Class Initialized
INFO - 2022-10-29 15:12:37 --> Security Class Initialized
DEBUG - 2022-10-29 15:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:12:37 --> Input Class Initialized
INFO - 2022-10-29 15:12:37 --> Language Class Initialized
INFO - 2022-10-29 15:12:37 --> Loader Class Initialized
INFO - 2022-10-29 15:12:37 --> Helper loaded: url_helper
INFO - 2022-10-29 15:12:37 --> Helper loaded: file_helper
INFO - 2022-10-29 15:12:37 --> Helper loaded: session_helper
INFO - 2022-10-29 15:12:37 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:12:37 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:12:37 --> Database Driver Class Initialized
INFO - 2022-10-29 15:12:37 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:12:37 --> Controller Class Initialized
INFO - 2022-10-29 15:12:37 --> File loaded: /var/www/app/omahan/application/views/login/index.php
INFO - 2022-10-29 15:12:37 --> Final output sent to browser
DEBUG - 2022-10-29 15:12:37 --> Total execution time: 0.2018
INFO - 2022-10-29 15:12:39 --> Config Class Initialized
INFO - 2022-10-29 15:12:39 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:12:39 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:12:39 --> Utf8 Class Initialized
INFO - 2022-10-29 15:12:39 --> URI Class Initialized
INFO - 2022-10-29 15:12:39 --> Router Class Initialized
INFO - 2022-10-29 15:12:39 --> Output Class Initialized
INFO - 2022-10-29 15:12:39 --> Security Class Initialized
DEBUG - 2022-10-29 15:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:12:39 --> Input Class Initialized
INFO - 2022-10-29 15:12:39 --> Language Class Initialized
INFO - 2022-10-29 15:12:39 --> Loader Class Initialized
INFO - 2022-10-29 15:12:39 --> Helper loaded: url_helper
INFO - 2022-10-29 15:12:39 --> Helper loaded: file_helper
INFO - 2022-10-29 15:12:39 --> Helper loaded: session_helper
INFO - 2022-10-29 15:12:39 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:12:39 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:12:39 --> Database Driver Class Initialized
INFO - 2022-10-29 15:12:39 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:12:39 --> Controller Class Initialized
INFO - 2022-10-29 15:12:43 --> Config Class Initialized
INFO - 2022-10-29 15:12:43 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:12:43 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:12:43 --> Utf8 Class Initialized
INFO - 2022-10-29 15:12:43 --> URI Class Initialized
INFO - 2022-10-29 15:12:43 --> Router Class Initialized
INFO - 2022-10-29 15:12:43 --> Output Class Initialized
INFO - 2022-10-29 15:12:43 --> Security Class Initialized
DEBUG - 2022-10-29 15:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:12:43 --> Input Class Initialized
INFO - 2022-10-29 15:12:43 --> Language Class Initialized
INFO - 2022-10-29 15:12:43 --> Loader Class Initialized
INFO - 2022-10-29 15:12:43 --> Helper loaded: url_helper
INFO - 2022-10-29 15:12:43 --> Helper loaded: file_helper
INFO - 2022-10-29 15:12:43 --> Helper loaded: session_helper
INFO - 2022-10-29 15:12:43 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:12:43 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:12:43 --> Database Driver Class Initialized
INFO - 2022-10-29 15:12:43 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:12:43 --> Controller Class Initialized
INFO - 2022-10-29 15:12:48 --> Config Class Initialized
INFO - 2022-10-29 15:12:48 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:12:48 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:12:48 --> Utf8 Class Initialized
INFO - 2022-10-29 15:12:48 --> URI Class Initialized
INFO - 2022-10-29 15:12:48 --> Router Class Initialized
INFO - 2022-10-29 15:12:48 --> Output Class Initialized
INFO - 2022-10-29 15:12:48 --> Security Class Initialized
DEBUG - 2022-10-29 15:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:12:48 --> Input Class Initialized
INFO - 2022-10-29 15:12:48 --> Language Class Initialized
INFO - 2022-10-29 15:12:48 --> Loader Class Initialized
INFO - 2022-10-29 15:12:48 --> Helper loaded: url_helper
INFO - 2022-10-29 15:12:48 --> Helper loaded: file_helper
INFO - 2022-10-29 15:12:48 --> Helper loaded: session_helper
INFO - 2022-10-29 15:12:48 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:12:48 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:12:48 --> Database Driver Class Initialized
INFO - 2022-10-29 15:12:48 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:12:48 --> Controller Class Initialized
INFO - 2022-10-29 15:12:59 --> Config Class Initialized
INFO - 2022-10-29 15:12:59 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:12:59 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:12:59 --> Utf8 Class Initialized
INFO - 2022-10-29 15:12:59 --> URI Class Initialized
INFO - 2022-10-29 15:12:59 --> Router Class Initialized
INFO - 2022-10-29 15:12:59 --> Output Class Initialized
INFO - 2022-10-29 15:12:59 --> Security Class Initialized
DEBUG - 2022-10-29 15:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:12:59 --> Input Class Initialized
INFO - 2022-10-29 15:12:59 --> Language Class Initialized
INFO - 2022-10-29 15:12:59 --> Loader Class Initialized
INFO - 2022-10-29 15:12:59 --> Helper loaded: url_helper
INFO - 2022-10-29 15:12:59 --> Helper loaded: file_helper
INFO - 2022-10-29 15:12:59 --> Helper loaded: session_helper
INFO - 2022-10-29 15:12:59 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:12:59 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:12:59 --> Database Driver Class Initialized
INFO - 2022-10-29 15:12:59 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:12:59 --> Controller Class Initialized
INFO - 2022-10-29 15:13:00 --> Config Class Initialized
INFO - 2022-10-29 15:13:00 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:13:00 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:13:00 --> Utf8 Class Initialized
INFO - 2022-10-29 15:13:00 --> URI Class Initialized
INFO - 2022-10-29 15:13:00 --> Router Class Initialized
INFO - 2022-10-29 15:13:00 --> Output Class Initialized
INFO - 2022-10-29 15:13:00 --> Security Class Initialized
DEBUG - 2022-10-29 15:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:13:00 --> Input Class Initialized
INFO - 2022-10-29 15:13:00 --> Language Class Initialized
INFO - 2022-10-29 15:13:00 --> Loader Class Initialized
INFO - 2022-10-29 15:13:00 --> Helper loaded: url_helper
INFO - 2022-10-29 15:13:00 --> Helper loaded: file_helper
INFO - 2022-10-29 15:13:00 --> Helper loaded: session_helper
INFO - 2022-10-29 15:13:00 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:13:00 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:13:00 --> Database Driver Class Initialized
INFO - 2022-10-29 15:13:00 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:13:00 --> Controller Class Initialized
INFO - 2022-10-29 15:13:00 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_admin.php
INFO - 2022-10-29 15:13:00 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index.php
INFO - 2022-10-29 15:13:00 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index_js.php
INFO - 2022-10-29 15:13:00 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 15:13:00 --> Final output sent to browser
DEBUG - 2022-10-29 15:13:00 --> Total execution time: 0.1655
INFO - 2022-10-29 15:13:05 --> Config Class Initialized
INFO - 2022-10-29 15:13:05 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:13:05 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:13:05 --> Utf8 Class Initialized
INFO - 2022-10-29 15:13:05 --> URI Class Initialized
INFO - 2022-10-29 15:13:05 --> Router Class Initialized
INFO - 2022-10-29 15:13:05 --> Output Class Initialized
INFO - 2022-10-29 15:13:05 --> Security Class Initialized
DEBUG - 2022-10-29 15:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:13:05 --> Input Class Initialized
INFO - 2022-10-29 15:13:05 --> Language Class Initialized
INFO - 2022-10-29 15:13:05 --> Loader Class Initialized
INFO - 2022-10-29 15:13:05 --> Helper loaded: url_helper
INFO - 2022-10-29 15:13:05 --> Helper loaded: file_helper
INFO - 2022-10-29 15:13:05 --> Helper loaded: session_helper
INFO - 2022-10-29 15:13:05 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:13:05 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:13:05 --> Database Driver Class Initialized
INFO - 2022-10-29 15:13:05 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:13:05 --> Controller Class Initialized
INFO - 2022-10-29 15:13:05 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_admin.php
INFO - 2022-10-29 15:13:05 --> File loaded: /var/www/app/omahan/application/views/profil/index.php
INFO - 2022-10-29 15:13:05 --> File loaded: /var/www/app/omahan/application/views/profil/index_js.php
INFO - 2022-10-29 15:13:05 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 15:13:05 --> Final output sent to browser
DEBUG - 2022-10-29 15:13:05 --> Total execution time: 0.1526
INFO - 2022-10-29 15:13:06 --> Config Class Initialized
INFO - 2022-10-29 15:13:06 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:13:06 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:13:06 --> Utf8 Class Initialized
INFO - 2022-10-29 15:13:06 --> URI Class Initialized
INFO - 2022-10-29 15:13:06 --> Router Class Initialized
INFO - 2022-10-29 15:13:06 --> Output Class Initialized
INFO - 2022-10-29 15:13:06 --> Security Class Initialized
DEBUG - 2022-10-29 15:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:13:06 --> Input Class Initialized
INFO - 2022-10-29 15:13:06 --> Language Class Initialized
INFO - 2022-10-29 15:13:06 --> Loader Class Initialized
INFO - 2022-10-29 15:13:06 --> Helper loaded: url_helper
INFO - 2022-10-29 15:13:06 --> Helper loaded: file_helper
INFO - 2022-10-29 15:13:06 --> Helper loaded: session_helper
INFO - 2022-10-29 15:13:06 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:13:06 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:13:06 --> Database Driver Class Initialized
INFO - 2022-10-29 15:13:07 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:13:07 --> Controller Class Initialized
INFO - 2022-10-29 15:13:07 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_admin.php
INFO - 2022-10-29 15:13:07 --> File loaded: /var/www/app/omahan/application/views/profil/edit.php
INFO - 2022-10-29 15:13:07 --> File loaded: /var/www/app/omahan/application/views/profil/edit_js.php
INFO - 2022-10-29 15:13:07 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 15:13:07 --> Final output sent to browser
DEBUG - 2022-10-29 15:13:07 --> Total execution time: 0.4429
INFO - 2022-10-29 15:14:36 --> Config Class Initialized
INFO - 2022-10-29 15:14:36 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:14:36 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:14:36 --> Utf8 Class Initialized
INFO - 2022-10-29 15:14:36 --> URI Class Initialized
INFO - 2022-10-29 15:14:36 --> Router Class Initialized
INFO - 2022-10-29 15:14:36 --> Output Class Initialized
INFO - 2022-10-29 15:14:36 --> Security Class Initialized
DEBUG - 2022-10-29 15:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:14:36 --> Input Class Initialized
INFO - 2022-10-29 15:14:36 --> Language Class Initialized
INFO - 2022-10-29 15:14:36 --> Loader Class Initialized
INFO - 2022-10-29 15:14:36 --> Helper loaded: url_helper
INFO - 2022-10-29 15:14:36 --> Helper loaded: file_helper
INFO - 2022-10-29 15:14:36 --> Helper loaded: session_helper
INFO - 2022-10-29 15:14:36 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:14:36 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:14:36 --> Database Driver Class Initialized
INFO - 2022-10-29 15:14:36 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:14:36 --> Controller Class Initialized
ERROR - 2022-10-29 15:14:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'joinref_kelurahan c on c.kode_wilayah=a.kode_kel
                where a.id='2'' at line 5 - Invalid query: SELECT 
                a.*, b.nama as nama_kec, c.nama as nama_kel
                from data_user a 
                left join ref_kecamatan b on b.kode_wilayah=a.kode_kec
                left joinref_kelurahan c on c.kode_wilayah=a.kode_kel
                where a.id='2'
            
INFO - 2022-10-29 15:14:36 --> Language file loaded: language/english/db_lang.php
INFO - 2022-10-29 15:14:47 --> Config Class Initialized
INFO - 2022-10-29 15:14:47 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:14:48 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:14:48 --> Utf8 Class Initialized
INFO - 2022-10-29 15:14:48 --> URI Class Initialized
INFO - 2022-10-29 15:14:48 --> Router Class Initialized
INFO - 2022-10-29 15:14:48 --> Output Class Initialized
INFO - 2022-10-29 15:14:48 --> Security Class Initialized
DEBUG - 2022-10-29 15:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:14:48 --> Input Class Initialized
INFO - 2022-10-29 15:14:48 --> Language Class Initialized
INFO - 2022-10-29 15:14:48 --> Loader Class Initialized
INFO - 2022-10-29 15:14:48 --> Helper loaded: url_helper
INFO - 2022-10-29 15:14:48 --> Helper loaded: file_helper
INFO - 2022-10-29 15:14:48 --> Helper loaded: session_helper
INFO - 2022-10-29 15:14:48 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:14:48 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:14:48 --> Database Driver Class Initialized
INFO - 2022-10-29 15:14:48 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:14:48 --> Controller Class Initialized
INFO - 2022-10-29 15:14:48 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_admin.php
INFO - 2022-10-29 15:14:48 --> File loaded: /var/www/app/omahan/application/views/profil/edit.php
INFO - 2022-10-29 15:14:48 --> File loaded: /var/www/app/omahan/application/views/profil/edit_js.php
INFO - 2022-10-29 15:14:48 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 15:14:48 --> Final output sent to browser
DEBUG - 2022-10-29 15:14:48 --> Total execution time: 0.4418
INFO - 2022-10-29 15:15:24 --> Config Class Initialized
INFO - 2022-10-29 15:15:24 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:15:24 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:15:24 --> Utf8 Class Initialized
INFO - 2022-10-29 15:15:24 --> URI Class Initialized
INFO - 2022-10-29 15:15:24 --> Router Class Initialized
INFO - 2022-10-29 15:15:24 --> Output Class Initialized
INFO - 2022-10-29 15:15:24 --> Security Class Initialized
DEBUG - 2022-10-29 15:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:15:24 --> Input Class Initialized
INFO - 2022-10-29 15:15:24 --> Language Class Initialized
INFO - 2022-10-29 15:15:24 --> Loader Class Initialized
INFO - 2022-10-29 15:15:24 --> Helper loaded: url_helper
INFO - 2022-10-29 15:15:24 --> Helper loaded: file_helper
INFO - 2022-10-29 15:15:24 --> Helper loaded: session_helper
INFO - 2022-10-29 15:15:24 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:15:24 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:15:24 --> Database Driver Class Initialized
INFO - 2022-10-29 15:15:24 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:15:24 --> Controller Class Initialized
INFO - 2022-10-29 15:15:24 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_admin.php
INFO - 2022-10-29 15:15:24 --> File loaded: /var/www/app/omahan/application/views/profil/edit.php
INFO - 2022-10-29 15:15:24 --> File loaded: /var/www/app/omahan/application/views/profil/edit_js.php
INFO - 2022-10-29 15:15:24 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 15:15:24 --> Final output sent to browser
DEBUG - 2022-10-29 15:15:24 --> Total execution time: 0.4766
INFO - 2022-10-29 15:15:50 --> Config Class Initialized
INFO - 2022-10-29 15:15:50 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:15:50 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:15:50 --> Utf8 Class Initialized
INFO - 2022-10-29 15:15:50 --> URI Class Initialized
INFO - 2022-10-29 15:15:50 --> Router Class Initialized
INFO - 2022-10-29 15:15:50 --> Output Class Initialized
INFO - 2022-10-29 15:15:50 --> Security Class Initialized
DEBUG - 2022-10-29 15:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:15:50 --> Input Class Initialized
INFO - 2022-10-29 15:15:50 --> Language Class Initialized
INFO - 2022-10-29 15:15:50 --> Loader Class Initialized
INFO - 2022-10-29 15:15:50 --> Helper loaded: url_helper
INFO - 2022-10-29 15:15:50 --> Helper loaded: file_helper
INFO - 2022-10-29 15:15:50 --> Helper loaded: session_helper
INFO - 2022-10-29 15:15:50 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:15:50 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:15:50 --> Database Driver Class Initialized
INFO - 2022-10-29 15:15:50 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:15:50 --> Controller Class Initialized
INFO - 2022-10-29 15:15:50 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_admin.php
INFO - 2022-10-29 15:15:50 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index.php
INFO - 2022-10-29 15:15:50 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index_js.php
INFO - 2022-10-29 15:15:50 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 15:15:50 --> Final output sent to browser
DEBUG - 2022-10-29 15:15:50 --> Total execution time: 0.1546
INFO - 2022-10-29 15:15:59 --> Config Class Initialized
INFO - 2022-10-29 15:15:59 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:15:59 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:15:59 --> Utf8 Class Initialized
INFO - 2022-10-29 15:15:59 --> URI Class Initialized
INFO - 2022-10-29 15:15:59 --> Router Class Initialized
INFO - 2022-10-29 15:15:59 --> Output Class Initialized
INFO - 2022-10-29 15:15:59 --> Security Class Initialized
DEBUG - 2022-10-29 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:15:59 --> Input Class Initialized
INFO - 2022-10-29 15:15:59 --> Language Class Initialized
INFO - 2022-10-29 15:15:59 --> Loader Class Initialized
INFO - 2022-10-29 15:15:59 --> Helper loaded: url_helper
INFO - 2022-10-29 15:15:59 --> Helper loaded: file_helper
INFO - 2022-10-29 15:15:59 --> Helper loaded: session_helper
INFO - 2022-10-29 15:15:59 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:15:59 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:15:59 --> Database Driver Class Initialized
INFO - 2022-10-29 15:15:59 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:15:59 --> Controller Class Initialized
INFO - 2022-10-29 15:15:59 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_admin.php
INFO - 2022-10-29 15:15:59 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index.php
INFO - 2022-10-29 15:15:59 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index_js.php
INFO - 2022-10-29 15:15:59 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 15:15:59 --> Final output sent to browser
DEBUG - 2022-10-29 15:15:59 --> Total execution time: 0.1543
INFO - 2022-10-29 15:16:10 --> Config Class Initialized
INFO - 2022-10-29 15:16:10 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:16:10 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:16:10 --> Utf8 Class Initialized
INFO - 2022-10-29 15:16:10 --> URI Class Initialized
INFO - 2022-10-29 15:16:10 --> Router Class Initialized
INFO - 2022-10-29 15:16:10 --> Output Class Initialized
INFO - 2022-10-29 15:16:10 --> Security Class Initialized
DEBUG - 2022-10-29 15:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:16:10 --> Input Class Initialized
INFO - 2022-10-29 15:16:10 --> Language Class Initialized
INFO - 2022-10-29 15:16:10 --> Loader Class Initialized
INFO - 2022-10-29 15:16:10 --> Helper loaded: url_helper
INFO - 2022-10-29 15:16:10 --> Helper loaded: file_helper
INFO - 2022-10-29 15:16:10 --> Helper loaded: session_helper
INFO - 2022-10-29 15:16:10 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:16:10 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:16:10 --> Database Driver Class Initialized
INFO - 2022-10-29 15:16:10 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:16:10 --> Controller Class Initialized
INFO - 2022-10-29 15:16:10 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_admin.php
INFO - 2022-10-29 15:16:10 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index.php
INFO - 2022-10-29 15:16:10 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index_js.php
INFO - 2022-10-29 15:16:10 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 15:16:10 --> Final output sent to browser
DEBUG - 2022-10-29 15:16:10 --> Total execution time: 0.1516
INFO - 2022-10-29 15:16:19 --> Config Class Initialized
INFO - 2022-10-29 15:16:19 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:16:19 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:16:19 --> Utf8 Class Initialized
INFO - 2022-10-29 15:16:19 --> URI Class Initialized
INFO - 2022-10-29 15:16:19 --> Router Class Initialized
INFO - 2022-10-29 15:16:19 --> Output Class Initialized
INFO - 2022-10-29 15:16:19 --> Security Class Initialized
DEBUG - 2022-10-29 15:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:16:19 --> Input Class Initialized
INFO - 2022-10-29 15:16:19 --> Language Class Initialized
INFO - 2022-10-29 15:16:19 --> Loader Class Initialized
INFO - 2022-10-29 15:16:19 --> Helper loaded: url_helper
INFO - 2022-10-29 15:16:19 --> Helper loaded: file_helper
INFO - 2022-10-29 15:16:19 --> Helper loaded: session_helper
INFO - 2022-10-29 15:16:19 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:16:19 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:16:19 --> Database Driver Class Initialized
INFO - 2022-10-29 15:16:19 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:16:19 --> Controller Class Initialized
INFO - 2022-10-29 15:16:19 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_admin.php
INFO - 2022-10-29 15:16:19 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index.php
INFO - 2022-10-29 15:16:19 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index_js.php
INFO - 2022-10-29 15:16:19 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 15:16:19 --> Final output sent to browser
DEBUG - 2022-10-29 15:16:20 --> Total execution time: 0.1590
INFO - 2022-10-29 15:16:39 --> Config Class Initialized
INFO - 2022-10-29 15:16:39 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:16:39 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:16:39 --> Utf8 Class Initialized
INFO - 2022-10-29 15:16:39 --> URI Class Initialized
INFO - 2022-10-29 15:16:39 --> Router Class Initialized
INFO - 2022-10-29 15:16:39 --> Output Class Initialized
INFO - 2022-10-29 15:16:39 --> Security Class Initialized
DEBUG - 2022-10-29 15:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:16:39 --> Input Class Initialized
INFO - 2022-10-29 15:16:39 --> Language Class Initialized
INFO - 2022-10-29 15:16:39 --> Loader Class Initialized
INFO - 2022-10-29 15:16:39 --> Helper loaded: url_helper
INFO - 2022-10-29 15:16:39 --> Helper loaded: file_helper
INFO - 2022-10-29 15:16:39 --> Helper loaded: session_helper
INFO - 2022-10-29 15:16:39 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:16:39 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:16:39 --> Database Driver Class Initialized
INFO - 2022-10-29 15:16:39 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:16:39 --> Controller Class Initialized
INFO - 2022-10-29 15:16:39 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_admin.php
INFO - 2022-10-29 15:16:39 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index.php
INFO - 2022-10-29 15:16:39 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index_js.php
INFO - 2022-10-29 15:16:39 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 15:16:39 --> Final output sent to browser
DEBUG - 2022-10-29 15:16:39 --> Total execution time: 0.1527
INFO - 2022-10-29 15:16:50 --> Config Class Initialized
INFO - 2022-10-29 15:16:50 --> Hooks Class Initialized
DEBUG - 2022-10-29 15:16:50 --> UTF-8 Support Enabled
INFO - 2022-10-29 15:16:50 --> Utf8 Class Initialized
INFO - 2022-10-29 15:16:50 --> URI Class Initialized
INFO - 2022-10-29 15:16:50 --> Router Class Initialized
INFO - 2022-10-29 15:16:50 --> Output Class Initialized
INFO - 2022-10-29 15:16:50 --> Security Class Initialized
DEBUG - 2022-10-29 15:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-29 15:16:50 --> Input Class Initialized
INFO - 2022-10-29 15:16:50 --> Language Class Initialized
INFO - 2022-10-29 15:16:50 --> Loader Class Initialized
INFO - 2022-10-29 15:16:50 --> Helper loaded: url_helper
INFO - 2022-10-29 15:16:50 --> Helper loaded: file_helper
INFO - 2022-10-29 15:16:50 --> Helper loaded: session_helper
INFO - 2022-10-29 15:16:50 --> Helper loaded: fungsi_helper
INFO - 2022-10-29 15:16:50 --> Helper loaded: referensi_helper
INFO - 2022-10-29 15:16:50 --> Database Driver Class Initialized
INFO - 2022-10-29 15:16:50 --> Session: Class initialized using 'database' driver.
INFO - 2022-10-29 15:16:50 --> Controller Class Initialized
INFO - 2022-10-29 15:16:50 --> File loaded: /var/www/app/omahan/application/views/template/sidebar_admin.php
INFO - 2022-10-29 15:16:50 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index.php
INFO - 2022-10-29 15:16:50 --> File loaded: /var/www/app/omahan/application/views/admin/dashboard/index_js.php
INFO - 2022-10-29 15:16:50 --> File loaded: /var/www/app/omahan/application/views/template/main.php
INFO - 2022-10-29 15:16:50 --> Final output sent to browser
DEBUG - 2022-10-29 15:16:50 --> Total execution time: 0.1590
