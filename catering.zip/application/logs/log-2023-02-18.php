<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-02-18 09:46:03 --> 404 Page Not Found: admin/Paketan/index
ERROR - 2023-02-18 09:56:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Table_paketan /var/www/app/catering/system/core/Loader.php 348
ERROR - 2023-02-18 10:28:49 --> Query error: Unknown column 'id_menu' in 'field list' - Invalid query: INSERT INTO `paketan` (`created`, `id_menu`, `id_paketan`) VALUES ('2023-02-18 10:28:49','1',1), ('2023-02-18 10:28:49','2',1)
ERROR - 2023-02-18 11:28:19 --> Severity: Notice --> Undefined variable: data_menu /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Notice --> Undefined variable: data_menu /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Notice --> Undefined variable: data_menu /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Notice --> Undefined variable: data_menu /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Notice --> Undefined variable: data_menu /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Notice --> Undefined variable: data_menu /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Notice --> Undefined variable: data_menu /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Notice --> Undefined variable: data_menu /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:28:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 11:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/app/catering/application/views/admin/paketan/form.php 12
ERROR - 2023-02-18 12:47:41 --> Severity: Notice --> Undefined property: stdClass::$harga /var/www/app/catering/application/controllers/user/Menu_list.php 151
ERROR - 2023-02-18 12:47:41 --> Severity: Notice --> Undefined property: stdClass::$harga /var/www/app/catering/application/controllers/user/Menu_list.php 151
ERROR - 2023-02-18 12:47:41 --> Severity: Notice --> Undefined property: stdClass::$harga /var/www/app/catering/application/controllers/user/Menu_list.php 151
ERROR - 2023-02-18 12:47:41 --> Query error: Unknown column 'harga_menu' in 'field list' - Invalid query: INSERT INTO `pesanan` (`created`, `harga_menu`, `id_menu`, `id_user`, `jenis`, `quantity`, `status`, `sub_total`) VALUES ('2023-02-18 12:47:41',NULL,'6','3','menu','3','1','16500'), ('2023-02-18 12:47:41',NULL,'3','3','menu','2','1','50000'), ('2023-02-18 12:47:41',NULL,'2','3','paketan','1','1','38000')
ERROR - 2023-02-18 12:47:48 --> Severity: Notice --> Undefined property: stdClass::$harga /var/www/app/catering/application/controllers/user/Menu_list.php 151
ERROR - 2023-02-18 12:47:48 --> Severity: Notice --> Undefined property: stdClass::$harga /var/www/app/catering/application/controllers/user/Menu_list.php 151
ERROR - 2023-02-18 12:47:48 --> Severity: Notice --> Undefined property: stdClass::$harga /var/www/app/catering/application/controllers/user/Menu_list.php 151
ERROR - 2023-02-18 12:47:48 --> Query error: Unknown column 'harga_menu' in 'field list' - Invalid query: INSERT INTO `pesanan` (`created`, `harga_menu`, `id_menu`, `id_user`, `jenis`, `quantity`, `status`, `sub_total`) VALUES ('2023-02-18 12:47:48',NULL,'6','3','menu','3','1','16500'), ('2023-02-18 12:47:48',NULL,'3','3','menu','2','1','50000'), ('2023-02-18 12:47:48',NULL,'2','3','paketan','1','1','38000')
ERROR - 2023-02-18 12:57:33 --> 404 Page Not Found: user/Tentang/index
ERROR - 2023-02-18 13:00:04 --> 404 Page Not Found: user/Tentang/index
ERROR - 2023-02-18 13:04:39 --> 404 Page Not Found: user/Page/cara_pesan
ERROR - 2023-02-18 13:05:22 --> 404 Page Not Found: user/Pesanan/index
ERROR - 2023-02-18 13:07:04 --> 404 Page Not Found: admin/Page/tentang_kami
ERROR - 2023-02-18 13:17:53 --> Severity: Notice --> Undefined property: Page::$upload /var/www/app/catering/application/controllers/admin/Page.php 69
ERROR - 2023-02-18 13:17:53 --> Severity: error --> Exception: Call to a member function initialize() on null /var/www/app/catering/application/controllers/admin/Page.php 69
ERROR - 2023-02-18 13:18:05 --> Severity: Notice --> Undefined property: Page::$upload /var/www/app/catering/application/controllers/admin/Page.php 69
ERROR - 2023-02-18 13:18:05 --> Severity: error --> Exception: Call to a member function initialize() on null /var/www/app/catering/application/controllers/admin/Page.php 69
ERROR - 2023-02-18 13:20:08 --> The path to the image is not correct.
ERROR - 2023-02-18 13:20:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-02-18 13:28:21 --> 404 Page Not Found: admin/Page/preview
ERROR - 2023-02-18 13:30:53 --> 404 Page Not Found: admin/Page/cara_pemesanan
ERROR - 2023-02-18 13:31:10 --> 404 Page Not Found: admin/Page/cara_pemesanan
ERROR - 2023-02-18 13:34:42 --> The path to the image is not correct.
ERROR - 2023-02-18 13:34:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-02-18 13:42:29 --> 404 Page Not Found: user/Pesanan/index
ERROR - 2023-02-18 13:44:40 --> 404 Page Not Found: user/Pesanan/index
