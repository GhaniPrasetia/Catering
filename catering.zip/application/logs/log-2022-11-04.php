<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-04 13:03:08 --> 404 Page Not Found: Uploads/img
ERROR - 2022-11-04 13:05:57 --> 404 Page Not Found: Uploads/img
