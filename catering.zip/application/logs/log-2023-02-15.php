<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-02-15 00:02:50 --> 404 Page Not Found: admin/Menu/kategori
ERROR - 2023-02-15 00:04:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Table_menu_kategori /var/www/app/catering/system/core/Loader.php 348
ERROR - 2023-02-15 00:12:30 --> 404 Page Not Found: admin/Menu/list
ERROR - 2023-02-15 00:18:11 --> 404 Page Not Found: admin/Menu/tambah
ERROR - 2023-02-15 00:18:15 --> 404 Page Not Found: admin/Menu/tambah
ERROR - 2023-02-15 08:30:59 --> 404 Page Not Found: admin/Menu/tambah
