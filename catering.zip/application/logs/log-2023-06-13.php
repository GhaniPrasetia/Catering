<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-13 21:14:44 --> Severity: error --> Exception: Call to undefined function my_csrf() /var/www/app/catering/application/views/login/registrasi.php 162
ERROR - 2023-06-13 21:15:33 --> Severity: error --> Exception: Call to undefined function my_csrf() /var/www/app/catering/application/views/login/registrasi.php 160
ERROR - 2023-06-13 21:21:37 --> Query error: Unknown column 'ktp' in 'where clause' - Invalid query: SELECT * from data_user where ktp='082332461946' and deleted is null 
