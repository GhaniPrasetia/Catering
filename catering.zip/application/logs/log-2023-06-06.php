<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-06 20:37:45 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-06 20:37:46 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-06 20:37:47 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-06 20:37:49 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-06 20:38:00 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-06 20:38:01 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-06 20:38:04 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-06 20:38:09 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-06 21:04:35 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-06 21:05:30 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
