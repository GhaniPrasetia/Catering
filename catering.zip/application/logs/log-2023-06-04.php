<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-04 14:01:34 --> Severity: Notice --> Undefined variable: konten /var/www/app/catering/application/views/front/front_template.php 121
ERROR - 2023-06-04 14:03:20 --> Severity: Notice --> Undefined property: Menu::$id_akun /var/www/app/catering/application/controllers/Menu.php 51
ERROR - 2023-06-04 14:03:24 --> Severity: Notice --> Undefined property: Menu::$id_akun /var/www/app/catering/application/controllers/Menu.php 51
ERROR - 2023-06-04 20:47:57 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 20:47:58 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:41:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 2 - Invalid query: SELECT 
            * from ref_kecamatan where
        
ERROR - 2023-06-04 23:41:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 2 - Invalid query: SELECT 
            * from ref_kecamatan where
        
ERROR - 2023-06-04 23:41:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 2 - Invalid query: SELECT 
            * from ref_kecamatan where
        
ERROR - 2023-06-04 23:41:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 2 - Invalid query: SELECT 
            * from ref_kecamatan where
        
ERROR - 2023-06-04 23:41:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 2 - Invalid query: SELECT 
            * from ref_kecamatan where
        
ERROR - 2023-06-04 23:41:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 2 - Invalid query: SELECT 
            * from ref_kecamatan where
        
ERROR - 2023-06-04 23:44:32 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:44:35 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:44:35 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:44:39 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:44:44 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:44:49 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:44:49 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:44:50 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:44:50 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:44:51 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:44:51 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:07 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:19 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:20 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:20 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:20 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:21 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:21 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:22 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:23 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:23 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:23 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:26 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:37 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
ERROR - 2023-06-04 23:45:43 --> Severity: Notice --> Undefined variable: link C:\xampp7.4\htdocs\catering\application\controllers\Login.php 14
