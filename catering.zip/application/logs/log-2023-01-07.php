<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-07 10:43:21 --> 404 Page Not Found: Uploads/img
