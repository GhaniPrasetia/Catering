<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-02-17 10:31:56 --> 404 Page Not Found: admin/Menu/tambah
ERROR - 2023-02-17 10:35:28 --> 404 Page Not Found: admin/Menu/form
ERROR - 2023-02-17 10:42:31 --> Severity: Notice --> Undefined variable: kategori /var/www/app/catering/application/views/admin/menu/form.php 15
ERROR - 2023-02-17 10:42:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/app/catering/application/views/admin/menu/form.php 15
ERROR - 2023-02-17 11:19:10 --> 404 Page Not Found: admin/Menu/list
ERROR - 2023-02-17 13:11:38 --> 404 Page Not Found: admin/Menu/list
ERROR - 2023-02-17 13:12:23 --> 404 Page Not Found: admin/List_menu/index
ERROR - 2023-02-17 13:14:45 --> 404 Page Not Found: admin/List_menu/index
ERROR - 2023-02-17 13:14:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Table_menu_list /var/www/app/catering/system/core/Loader.php 348
ERROR - 2023-02-17 13:18:29 --> 404 Page Not Found: admin/Menu/list
ERROR - 2023-02-17 14:23:30 --> 404 Page Not Found: User/dashboard
ERROR - 2023-02-17 14:25:06 --> Severity: Notice --> Undefined variable: inc /var/www/app/catering/application/libraries/Templates.php 19
ERROR - 2023-02-17 14:25:38 --> Severity: Notice --> Undefined variable: inc /var/www/app/catering/application/libraries/Templates.php 19
ERROR - 2023-02-17 14:34:53 --> 404 Page Not Found: Assets/skote
ERROR - 2023-02-17 14:39:57 --> 404 Page Not Found: Assets/skote
ERROR - 2023-02-17 14:43:16 --> 404 Page Not Found: user/Menu_list/index
