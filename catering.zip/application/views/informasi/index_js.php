<script>
    $('#table_data').DataTable();
</script>