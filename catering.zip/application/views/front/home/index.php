<style>
    #welcome{
        width: 100%;
        height: 550px;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        background-color: #B1EBEC;
    }
</style>

<div class="row"> 
    <div class="col-md-12">
        <div class="card">
            <div class="card-body" id="welcome">
                <img src="<?= base_url('uploads/img/logo.png') ?>" alt="image" style="width: 150px;">
                <h1 class="fw-600">Selamat Datang</h1>
                <h3 class="fw-600">SIDOMULYO FOOD & CATERING</h3>
            </div>
        </div>
    </div>
</div>