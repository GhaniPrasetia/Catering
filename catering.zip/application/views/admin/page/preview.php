<div class="row" id="target_full_page">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body bg-primary1 br-atas p-3 mb-0 d-flex justify-content-between">
                <h3 style="display: inline-block;" class="fw-600 mb-0"><i class="fas fa-info-circle mr-2"></i> <?= $title ?></h3>
                <button onclick="window.close();" class="btn btn-primary btn-rounded fw-600">
                    <i class="fa fa-times mr-1"></i> tutup
                </button>
            </div>

            <div class="card-body">
               <?= $data->konten ?>
            </div>
        </div>
    </div>
</div>